<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: "App"
};
</script>

<style>
@import "./styles/base";
@import "./styles/pages/quarter/animate.scss";
</style>
